# אקורד 🎸 — הוראות העלאה ל-Netlify

אפליקציית לימוד גיטרה בעברית עם מאמן AI מבוסס Claude.

המאמן עובד דרך **Netlify Function** (שרת קטן) שמדבר עם Claude.
המפתח אף פעם לא נמצא בקוד שהמשתמש רואה — Netlify מזריקה אותו אוטומטית.

---

## מבנה הפרויקט

```
akord/
├── index.html              ← האפליקציה (מה שהמשתמש רואה)
├── netlify.toml            ← הגדרות Netlify
├── package.json            ← התלות בספריית Anthropic
└── netlify/
    └── functions/
        └── coach.js        ← השרת שמדבר עם Claude
```

---

## העלאה — שתי דרכים

### דרך א' — הכי פשוטה (גרירה לאתר)

1. דחוס את כל התיקייה `akord` לקובץ ZIP.
2. כנס ל-https://app.netlify.com ובחר **Add new site → Deploy manually**.
3. גרור את ה-ZIP. Netlify תזהה אוטומטית את ה-Function.

> שים לב: בדרך הזו Netlify לא תמיד מתקינה את התלויות (`npm install`).
> אם המאמן לא עונה — עבור לדרך ב'.

### דרך ב' — דרך GitHub (מומלץ, יציב יותר)

1. העלה את התיקייה `akord` ל-repository חדש ב-GitHub.
2. ב-Netlify: **Add new site → Import from Git** ובחר את ה-repo.
3. הגדרות Build:
   - **Build command:** `npm install`
   - **Publish directory:** `.`
4. לחץ **Deploy**.

---

## הפעלת ה-AI (קריטי!)

Netlify מציעה **AI Gateway** שמספק גישה ל-Claude בלי מפתח ידני.
כדי להפעיל:

1. בלוח הבקרה של האתר: **Site configuration → AI Gateway** (או **AI Features**).
2. ודא שהתכונה **מופעלת**. ברגע שהיא פעילה, Netlify מזריקה אוטומטית
   את `ANTHROPIC_API_KEY` ל-Function שלך — לא צריך להוסיף כלום.

> אם אתה מעדיף מפתח Anthropic משלך (לשליטה בעלות):
> 1. צור מפתח ב-https://console.anthropic.com
> 2. ב-Netlify: **Site configuration → Environment variables**
> 3. הוסף משתנה בשם `ANTHROPIC_API_KEY` עם הערך שלך.
> זה ידרוס את ברירת המחדל של ה-Gateway.

---

## בדיקה שהכל עובד

1. פתח את כתובת האתר שקיבלת (משהו כמו `your-site.netlify.app`).
2. עבור לטאב **מאמן** 🤖.
3. שאל שאלה — אם מגיעה תשובה אמיתית בעברית, הכל עובד! ✅
4. אם מופיע "תקלה בחיבור לשרת" — בדוק:
   - שה-AI Gateway מופעל (או שהוספת מפתח ידני)
   - שהתלויות הותקנו (דרך ב' פותרת את זה)
   - בלוג של ה-Function: **Site → Functions → coach → Logs**

---

## הערה על עלות

כרגע אין הגבלת שימוש — כל משתמש יכול לשאול ללא הגבלה.
לאפליקציה ציבורית, כדאי להוסיף בהמשך:
- הגבלת קצב (rate limiting) למניעת ניצול
- מעקב עלות בלוח הבקרה של Netlify / Anthropic

תגיד לי כשתרצה ואוסיף את זה.

---

## מה הלאה

הבסיס עומד. השלבים הבאים האפשריים:
- מסך שיעור מלא מבפנים (וידאו/אנימציה + תרגול)
- מסך שיר אינטראקטיבי (אקורדים שמתחלפים לפי הקצב)
- חיבור Supabase לשמירת התקדמות אמיתית בין משתמשים
- הגבלת קצב והגנת עלות
