# 🎸 אקורד — מדריך הקמת Supabase (שלב אחר שלב)

המדריך הזה לוקח אותך מאפס: יצירת פרויקט, מציאת המפתחות, הקמת הטבלה, והפעלת ההתחברות.
בצע את הצעדים **לפי הסדר**. כל צעד מסביר בדיוק איפה ללחוץ.

---

## שלב 1 — יצירת פרויקט Supabase

1. כנס ל-https://supabase.com ולחץ **Start your project** (או **Sign in** אם יש לך חשבון).
2. אחרי ההתחברות, לחץ **New project**.
3. מלא:
   - **Name:** `akord` (או כל שם)
   - **Database Password:** בחר סיסמה חזקה ו**שמור אותה** (תצטרך אותה אם תיגש למסד ישירות). זו לא הסיסמה של המשתמשים — זו סיסמת המנהל.
   - **Region:** בחר את הקרוב ביותר (למשל `Frankfurt` לאירופה/ישראל).
4. לחץ **Create new project** והמתן ~2 דקות עד שהפרויקט מוקם.

---

## שלב 2 — מציאת ה-URL וה-anon key (זה מה שהקוד צריך!)

1. בתפריט הצד השמאלי, לחץ על אייקון **⚙️ Project Settings** (למטה).
2. לחץ על **API** (או **Data API**).
3. תראה שני ערכים שאתה צריך להעתיק:

   **א. Project URL** — נראה כמו:
   ```
   https://abcdefghijk.supabase.co
   ```

   **ב. anon public key** — מחרוזת ארוכה שמתחילה ב-`eyJ...`
   (זה תחת "Project API keys" → השורה שכתוב לידה **anon** ו-**public**)

4. **שמור את שני הערכים האלה** — תכניס אותם לקוד בהמשך. ⚠️ ה-anon key בטוח לחשיפה בדפדפן (הוא ציבורי בכוונה). אל תשתמש ב-`service_role` key — הוא סודי ואסור לחשוף!

---

## שלב 3 — יצירת טבלת הפרופילים (הרצת SQL)

1. בתפריט הצד, לחץ על **SQL Editor** (אייקון `</>`).
2. לחץ **New query**.
3. העתק-הדבק את כל הקוד הבא **בדיוק כמו שהוא**:

```sql
-- טבלת פרופילים — מחזיקה התקדמות, רצף, נקודות לכל משתמש
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  display_name text,
  completed_lessons jsonb default '[]'::jsonb,
  current_lesson int default 1,
  streak_days int default 0,
  last_active date,
  xp int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- הפעלת אבטחה ברמת השורה (RLS) — כל משתמש רואה ועורך רק את עצמו
alter table public.profiles enable row level security;

create policy "משתמשים רואים את הפרופיל שלהם"
  on public.profiles for select
  using ( auth.uid() = id );

create policy "משתמשים מעדכנים את הפרופיל שלהם"
  on public.profiles for update
  using ( auth.uid() = id );

create policy "משתמשים יוצרים את הפרופיל שלהם"
  on public.profiles for insert
  with check ( auth.uid() = id );

-- יצירת פרופיל אוטומטית כשמשתמש נרשם
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

4. לחץ **Run** (או Ctrl+Enter). אמור להופיע "Success".

> מה הקוד עשה? יצר טבלה לשמירת התקדמות, הגדיר שכל משתמש ניגש רק לנתונים שלו (אבטחה),
> ודאג שכשמישהו נרשם — נוצר לו פרופיל ריק אוטומטית.

---

## שלב 4 — הפעלת התחברות עם אימייל+סיסמה

1. בתפריט הצד, לחץ **Authentication** → **Sign In / Providers** (או **Providers**).
2. ודא ש-**Email** מופעל (בדרך כלל פעיל כברירת מחדל).
3. **חשוב לבדיקה מהירה:** תחת Email, כבה זמנית את **Confirm email**
   (כך תוכל להתחבר מיד בלי לאמת מייל בזמן הפיתוח). תוכל להחזיר את זה לפני השקה אמיתית.

זהו! עכשיו אימייל+סיסמה עובד. אפשר להעלות ולבדוק.

---

## שלב 5 (אופציונלי, בהמשך) — הפעלת התחברות עם Google

זה דורש כמה צעדים נוספים. **דלג על זה בינתיים** והפעל אותו כשהבסיס עובד:

1. צור OAuth credentials ב-https://console.cloud.google.com
   (Create Project → APIs & Services → Credentials → OAuth client ID → Web application)
2. תחת "Authorized redirect URIs", הוסף את הכתובת שנותן לך Supabase
   (נמצאת ב-Authentication → Providers → Google).
3. העתק את ה-**Client ID** וה-**Client Secret** מ-Google אל Supabase.
4. הפעל את **Google** ב-Supabase והדבק את הערכים.

המדריך המלא: https://supabase.com/docs/guides/auth/social-login/auth-google

> הכפתור "התחבר עם Google" כבר קיים בקוד — הוא פשוט יעבוד ברגע שתפעיל את ה-provider.

---

## שלב 6 — הכנסת המפתחות לקוד

פתח את `index.html` וחפש (קרוב לתחילת ה-`<script>`) את השורות:

```javascript
const SUPABASE_URL = "כאן-הכתובת-שלך";
const SUPABASE_ANON_KEY = "כאן-המפתח-שלך";
```

החלף את הטקסט במרכאות בערכים שהעתקת בשלב 2. שמור והעלה ל-Netlify.

---

## בדיקה סופית ✅

1. פתח את האתר ב-Netlify.
2. אמור להופיע מסך התחברות.
3. לחץ "הרשמה", הזן אימייל וסיסמה, ולחץ הירשם.
4. אתה אמור להיכנס לאפליקציה — והפעם ההתקדמות שלך תישמר!
5. צא והיכנס שוב — ההתקדמות נשארת. 🎉

אם משהו לא עובד — פתח את ה-Console בדפדפן (F12) וחפש שגיאה אדומה,
ושלח לי אותה. נתקן ביחד.
```
